#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

if [ -z "${RELAY_SECRET:-}" ]; then
  echo "Error: RELAY_SECRET is not set. Copy .env.example to .env and edit it."
  exit 1
fi

if [ ! -d node_modules ]; then
  npm install --omit=dev
fi

exec npm start
